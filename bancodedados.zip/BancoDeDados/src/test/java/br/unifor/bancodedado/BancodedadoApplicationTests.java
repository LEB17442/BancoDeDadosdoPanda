package br.unifor.bancodedado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BancodedadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
