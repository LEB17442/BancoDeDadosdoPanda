package br.unifor.bancodedado.DTO;

public class UsuarioDTO {
    public String nome;
    public String email;
    public String matricula;
    public boolean isAdmin;
}
